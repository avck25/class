'use strict';

const Person = require('./Person');

//let bob = new Person.Person('Bob', 'bob@gmail.com');
let bob = new Person('Bob', 'bob@gmail.com');
bob.print();