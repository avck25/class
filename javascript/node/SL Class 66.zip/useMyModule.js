const mm = require('./myModule');
mm.sayHello();
mm.sayGoodbye();
//mm.getGreeting();

const mm2 = require('./myModule2');
mm2.sayHello();
mm2.sayGoodbye();

const sayHello = require('./myModule3');
sayHello();