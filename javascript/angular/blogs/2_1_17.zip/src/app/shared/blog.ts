export interface Blog {
    name: string;
    website: string;
    company: string;
    id: number;
}