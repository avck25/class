import { Item } from './item';

export interface Category {
    name: string;
    items?: Item[];
}